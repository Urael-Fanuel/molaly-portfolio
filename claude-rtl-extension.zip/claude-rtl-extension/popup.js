// popup.js – v1.2 | תיקון מונה אלמנטים

const toggle     = document.getElementById('toggle');
const statusPill = document.getElementById('status-pill');
const statusText = document.getElementById('status-text');
const fixedCount = document.getElementById('fixed-count');
const refreshBtn = document.getElementById('refresh-btn');

// טעינת מצב שמור
chrome.storage.sync.get({ rtlEnabled: true }, (data) => {
  toggle.checked = data.rtlEnabled;
  updateUI(data.rtlEnabled);
});

// שינוי מצב הפעלה/כיבוי
toggle.addEventListener('change', () => {
  const val = toggle.checked;
  chrome.storage.sync.set({ rtlEnabled: val });
  updateUI(val);
  chrome.tabs.query({ url: ['https://claude.ai/*', 'https://*.anthropic.com/*','https://chatgpt.com/*','https://gemini.google.com/*','https://copilot.microsoft.com/*'] }, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { type: 'SET_ENABLED', value: val }).catch(() => {});
    });
  });
});

// רענון דף
refreshBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.reload(tabs[0].id);
    window.close();
  });
});

function updateUI(isEnabled) {
  statusPill.className = 'status-pill ' + (isEnabled ? 'on' : 'off');
  statusText.textContent = isEnabled ? 'פעיל בדף זה' : 'כבוי';
}

// ── משיכת מונה אלמנטים מהטאב הפעיל ──
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (!tabs[0]) return;
  chrome.tabs.sendMessage(
    tabs[0].id,
    { type: 'GET_COUNT' },
    (response) => {
      if (chrome.runtime.lastError) return; // הטאב לא תומך בתוסף
      if (response && typeof response.count === 'number') {
        fixedCount.textContent = response.count;
      }
    }
  );
});
