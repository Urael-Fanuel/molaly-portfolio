// popup.js – לוגיקת הפופאפ

const toggle      = document.getElementById('toggle');
const statusPill  = document.getElementById('status-pill');
const statusText  = document.getElementById('status-text');
const fixedCount  = document.getElementById('fixed-count');
const refreshBtn  = document.getElementById('refresh-btn');

// טעינת מצב שמור
chrome.storage.sync.get({ rtlEnabled: true }, (data) => {
  toggle.checked = data.rtlEnabled;
  updateUI(data.rtlEnabled);
});

// שינוי מצב
toggle.addEventListener('change', () => {
  const val = toggle.checked;
  chrome.storage.sync.set({ rtlEnabled: val });
  updateUI(val);

  // שלח הודעה לכל הטאבים הפתוחים של קלוד
  chrome.tabs.query({ url: ['https://claude.ai/*', 'https://*.anthropic.com/*'] }, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { type: 'SET_ENABLED', value: val }).catch(() => {});
    });
  });
});

// רענון
refreshBtn.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.reload(tabs[0].id);
    window.close();
  });
});

function updateUI(isEnabled) {
  if (isEnabled) {
    statusPill.className = 'status-pill on';
    statusText.textContent = 'פעיל בדף זה';
  } else {
    statusPill.className = 'status-pill off';
    statusText.textContent = 'כבוי';
  }
}

// קריאת מונה תיקונים מהטאב הפעיל
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (!tabs[0]) return;
  chrome.storage.session && chrome.storage.session.get('fixedCount', (data) => {
    if (data && data.fixedCount) {
      fixedCount.textContent = data.fixedCount;
    }
  });
});
