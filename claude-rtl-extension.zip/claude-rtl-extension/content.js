/**
 * Claude RTL Fix – content.js v1.2
 * תיקון: מונה אלמנטים תקין + תגובה להודעת GET_COUNT
 */
(function () {
  'use strict';

  const HEBREW_RE = /[\u0590-\u05FF\uFB1D-\uFB4F]/;
  const ARABIC_RE = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
  const TEXT_TAGS = ['P','LI','H1','H2','H3','H4','H5','H6','BLOCKQUOTE','DT','DD'];
  const SKIP_TAGS = ['CODE','PRE','KBD','SAMP','SCRIPT','STYLE'];

  let enabled      = true;
  let observer     = null;
  let debounceTimer = null;
  let pendingNodes = [];
  let appliedCount = 0;  // ← מונה אלמנטים שתוקנו

  chrome.storage.sync.get({ rtlEnabled: true }, (data) => {
    enabled = data.rtlEnabled;
    if (enabled) start();
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'SET_ENABLED') {
      enabled = msg.value;
      enabled ? start() : (stop(), removeAllRTL());
    }
    if (msg.type === 'GET_COUNT') {
      sendResponse({ count: appliedCount });
      return true; // חובה לאסינכרוני
    }
  });

  function isRTL(text) {
    return HEBREW_RE.test(text) || ARABIC_RE.test(text);
  }

  function shouldSkip(el) {
    let node = el;
    while (node && node !== document.body) {
      if (SKIP_TAGS.includes(node.tagName)) return true;
      node = node.parentElement;
    }
    return false;
  }

  function applyRTL(el) {
    if (!el || el.dataset.claudeRtl === '1') return;
    if (shouldSkip(el)) return;
    const text = el.innerText || el.textContent || '';
    if (!text.trim() || !isRTL(text)) return;
    el.style.setProperty('direction',    'rtl',   'important');
    el.style.setProperty('text-align',   'right', 'important');
    el.style.setProperty('unicode-bidi', 'embed', 'important');
    el.dataset.claudeRtl = '1';
    appliedCount++;  // ← קידום המונה אחרי הצלחה
  }

  function removeRTL(el) {
    if (!el || el.dataset.claudeRtl !== '1') return;
    el.style.removeProperty('direction');
    el.style.removeProperty('text-align');
    el.style.removeProperty('unicode-bidi');
    delete el.dataset.claudeRtl;
  }

  function removeAllRTL() {
    document.querySelectorAll('[data-claude-rtl="1"]').forEach(removeRTL);
    appliedCount = 0;
  }

  function processNode(root) {
    if (!enabled || !root || root.nodeType !== 1) return;
    const selector = TEXT_TAGS.map(t => t.toLowerCase()).join(',');
    if (TEXT_TAGS.includes(root.tagName)) applyRTL(root);
    if (root.querySelectorAll) {
      root.querySelectorAll(selector).forEach(applyRTL);
    }
  }

  function scheduleProcess(node) {
    pendingNodes.push(node);
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const nodes = pendingNodes.splice(0);
      nodes.forEach(processNode);
    }, 400);
  }

  function start() {
    processNode(document.body);
    observer = new MutationObserver((mutations) => {
      if (!enabled) return;
      mutations.forEach((m) => {
        m.addedNodes.forEach((node) => {
          if (node.nodeType === 1) scheduleProcess(node);
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function stop() {
    if (observer) { observer.disconnect(); observer = null; }
    clearTimeout(debounceTimer);
    pendingNodes = [];
  }

})();
